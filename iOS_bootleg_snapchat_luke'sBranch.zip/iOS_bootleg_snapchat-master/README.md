# iOS_bootleg_snapchat

git add .
    This will add all local changes to a 'stage' that is ready to be committed locally
  
git add "fileName"
    This adds specified files instead of all changes
  
git commit -m "Insert comment here"
    This formally 'saves' the file to a local repository.

git push origin master
    Pushes the locally committed changes to the online GitHub repository

git pull
    Pulls any changes from the online repository down to your local computer

git status
    Tells you any differences between your last LOCAL commit and your current workspace
